# SCREENS INDEX — visual reference for each screen

These are the final, approved UI designs. When building a screen in the Flutter course,
open the matching PNG to see exactly what to build. The design system (colors,
typography, spacing) is in `../DESIGN.md`.

| File | Screen | Build in course lesson |
|---|---|---|
| `01_splash.png` | Splash / BLE scanning | F1.1–F1.4 |
| `02_home.png` | Home dashboard | F5.1 |
| `03_quick_prices.png` | Quick Prices (± steppers) | F5.2 |
| `04_weigh_and_select.png` | **Core billing screen (STABLE state)** — weight bar, bill switcher, category chips, tile grid, current items, dock | F2.4–F2.11 |
| `04b_settling_state.png` | **Same screen, SETTLING state** — amber weight bar, all tiles greyed/disabled | F2.7 |
| `05_piece_quantity.png` | Piece quantity bottom sheet | F2.9 |
| `06a_cart.png` | Cart (normal/collapsed discount) | F3.2–F3.4 |
| `06b_cart_set_total.png` | Cart (Set Total expanded inline) | F3.5 |
| `07_paid.png` | Paid confirmation | F3.6 |
| `08_stock.png` | Stock inventory | F5.3 |
| `09_add_product.png` | Add/Edit product (with category selector) | F5.4 |
| `10_restock_blocked.png` | Restock blocked by day-close gate | F5.5 |
| `11_day_close.png` | Day close / spoilage | F5.5 |

## Key visual rules (from DESIGN.md)
- **Primary green:** #0F766E (headers, key actions)
- **Dark forest green:** #064E3B (Mark paid, primary tactile buttons)
- **Amber:** #D97706 (settling/unstable weight states)
- **Stable emerald:** #10B981 (weight locked, confirmed)
- **Red:** #DC2626 (errors, out of stock, voids)
- **Numbers** use JetBrains Mono (tabular). **Text** uses Inter (min weight 500).
- **Tap targets:** min 48px, scaling to 60-64px for high-frequency actions (Tare,
  Add to Bill, Pay).
- Piece/bunch tiles have dashed borders. Weight items have solid.
